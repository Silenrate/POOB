import java.util.Stack;

/** 
 * Representa una calculadora de velocidades
 * @author ESCUELA 2018-01
 */
   

//No olvide documentar los métodos
public class SuperCalculadora{

    private Stack<Velocidad> operandos;
    //Consultar en el API Java la clase Stack
    
    public SuperCalculadora(){
    }

    
    public void adicione(int longitud, int grados){       
    }
    
    public void elimine(){
    }
    
    public void duplique(){
    }
    
    //Los caracteres de las operaciones posibles son: +, -, x (producto vectorial),h (velocidad horizontal), v (velocidad vertical)
    public void calcule(char operacion){
    }
  
    //Los caracteres de las operaciones posibles son: * (producto escalar), t velocidad después de un tiempo
    public void calcule(char operacion, int parametro){
    
    }
    
    public String consulte(){
        return null;
    }
    
    public boolean ok(){
        return false;
    }
}
    



