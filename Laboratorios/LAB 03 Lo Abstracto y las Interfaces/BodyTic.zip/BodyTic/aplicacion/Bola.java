package aplicacion;

public class Bola {

}
